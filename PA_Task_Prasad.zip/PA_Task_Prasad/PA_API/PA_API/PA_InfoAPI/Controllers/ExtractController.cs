﻿using Microsoft.AspNetCore.Mvc;
using PA_InfoISerice;

namespace PA_InfoAPI.Controllers
{
    /// <summary>
    /// The extract controller.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ExtractController : ControllerBase
    {
        private readonly IDataExtractService _dataExtractService;
        public ExtractController(IDataExtractService dataExtractService)
        {
            _dataExtractService = dataExtractService;
        }

        /// <summary>
        /// Data the snap.
        /// </summary>
        /// <returns>An IActionResult.</returns>
        [HttpGet()]
        public IActionResult DataExtract()
        {
            try
            {
                var report = _dataExtractService.DataReport();
                return new OkObjectResult(report);
            }
            catch (Exception)
            {
                throw;
            }
        }


        [HttpGet("Snap/{id}")]
        public IActionResult DataSnap(string id)
        {
            try
            {
                var dataSnap = _dataExtractService.DataSnap(id);
                return new OkObjectResult(dataSnap);
            }
            catch (Exception)
            {
                throw;
            }
           
        }

    }
}
