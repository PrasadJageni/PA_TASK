﻿using Newtonsoft.Json;
using PA_InfoCommon.Extensions;
using PA_InfoCommon.Models;
using PA_InfoISerice;

namespace PA_InfoService
{
    public class DataExtractService : IDataExtractService
    {
        private readonly string _logPath;

        /// <summary>
        /// Initializes a new instance of the <see cref="DataExtractService"/> class.
        /// </summary>
        /// <param name="apiSetting">The api setting.</param>
        public DataExtractService(LogSetting logSetting)
        {
            _logPath = logSetting.FilePath;
        }

        public DataSnap DataSnap(string id)
        {
            var dataSnap = new DataSnap();
            var dataExtact = new List<DataExtact>();
            var fileLines = FileHelper.ReadAllLinesOfAllFiles(_logPath);

            foreach (var item in fileLines)
            {
                var temp = item.Split("|");
                if (!temp.IsListNullOrEmpty())
                {
                    var logItem = TryDataObject(string.Join("|", temp.Skip(1)));

                    if (!logItem.IsNull() && id == logItem.ID)
                    {
                        logItem.Time = Convert.ToDateTime(temp[0]);
                        dataExtact.Add(logItem);
                    }
                }
            }
            if (dataExtact.Count > 0)
            {
                var request = dataExtact.Where(x => x.INFORMATION_TYPE.Equals("REQUEST")).FirstOrDefault();
                var response = dataExtact.Where(x => x.INFORMATION_TYPE.Equals("RESPONSE")).FirstOrDefault();
                dataSnap = new DataSnap()
                {
                    ID = id,
                    RequestTime = request?.Time,
                    Request = JsonConvert.SerializeObject(request.RawRequest),
                    ResponseTime = response?.Time,
                    Response = response?.Response,
                    Duration = response.Duration,
                };
            }
            return dataSnap;
        }

        public List<DataReport> DataReport()
        {
            var response = new List<DataReport>();
            var dataExtract = new List<DataExtact>();
            var fileLines = FileHelper.ReadAllLinesOfAllFiles(_logPath);

            foreach (var item in fileLines)
            {
                var temp = item.Split("|");
                if (temp.Length > 1)
                {
                    var logItem = TryDataObject(string.Join("|", temp.Skip(1)));

                    if (!logItem.IsNull())
                    {
                        logItem.Time = Convert.ToDateTime(temp[0]);
                        dataExtract.Add(logItem);
                    }
                }
            }

            response = (dataExtract.Where(x => x.INFORMATION_TYPE.Equals("REQUEST"))
                      .GroupBy(g => g.RawRequest.ApiId)
                      .Select(s => new DataReport
                      {
                          ApiId = s.Key,
                          Count = s.Count()
                      })).ToList();
            return response;
        }

        private DataExtact TryDataObject(string str)
        {
            try
            {
                return JsonConvert.DeserializeObject<DataExtact>(str);
            }
            catch (Exception)
            {
                return null;
            }
            return null;
        }
    }
}