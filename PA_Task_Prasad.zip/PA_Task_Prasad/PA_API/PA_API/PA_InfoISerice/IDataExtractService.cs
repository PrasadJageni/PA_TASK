﻿using PA_InfoCommon.Models;

namespace PA_InfoISerice
{
    /// <summary>
    /// The data extract service interface.
    /// </summary>
    public interface IDataExtractService
    {
        DataSnap DataSnap(string id);

        List<DataReport> DataReport();
    }
}