﻿namespace PA_InfoCommon.Models
{
    public class DataReport
    {
        public string ApiId { get; set; }
        public int Count { get; set; }
    }

    public class DataSnap
    {
        public string ID { get; set; }
        public DateTime? RequestTime { get; set; }
        public string Request { get; set; }
        public DateTime? ResponseTime { get; set; }
        public string Response { get; set; }
        public string Duration { get; set; }
    }
}
