﻿namespace PA_InfoCommon.Models
{
    public class Rawrequest
    {
        public string ApiId { get; set; }
        public Apiconnectioninformation ApiConnectionInformation { get; set; }
        public Infodictionary[] InfoDictionary { get; set; }
        public ApiType ApiType { get; set; }
    }
    public class Apiconnectioninformation
    {
        public string ApiUrl { get; set; }
        public object BillingUrl { get; set; }
        public string ApiUserName { get; set; }
        public string SoapApiUrl { get; set; }
        public string SoapApiUserName { get; set; }
    }

    public class Infodictionary
    {
        public string Key { get; set; }
        public object Value { get; set; }
        public int Type { get; set; }
        public bool IsGlobal { get; set; }
    }

}
