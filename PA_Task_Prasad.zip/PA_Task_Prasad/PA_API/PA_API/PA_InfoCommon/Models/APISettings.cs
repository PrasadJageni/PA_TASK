﻿namespace PA_InfoCommon.Models
{
    public class APISetting
    {
        public Logging Logging { get; set; }
        public string AllowedHosts { get; set; }
        public LogSetting LogSetting { get; set; }
    }

    public class Logging
    {
        public Loglevel LogLevel { get; set; }
    }

    public class Loglevel
    {
        public string Default { get; set; }
        public string MicrosoftAspNetCore { get; set; }
    }

    public class LogSetting
    {
        public string FilePath { get; set; }
    }

}
