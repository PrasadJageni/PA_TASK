﻿namespace PA_InfoCommon.Models
{
    public class DataExtact
    {
        public string INFORMATION_TYPE { get; set; }
        public string ID { get; set; }
        public string ApiId { get; set; }
        public string UserId { get; set; }
        public int ApiType { get; set; }
        public Rawrequest RawRequest { get; set; }
        public string Message { get; set; }
        public string Host { get; set; }
        public string Duration { get; set; }
        public string Response { get; set; }
        public DateTime Time { get; set; }
    }

    public class DataItem
    {
        public DateTime LogTime { get; set; }
        public DataExtact LogItem { get; set; }
    }
}
