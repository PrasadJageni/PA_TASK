﻿using Newtonsoft.Json;
using PA_InfoCommon.Models;

namespace PA_InfoCommon.Extensions
{
    public static class Extension
    {

        public static bool IsNull(this object ObjectNullable)
        {
            return (ObjectNullable == null);
        }
        public static bool IsListNullOrEmpty<T>(this IEnumerable<T> listObj)
        {
            if (listObj == null) { return true; }
            return !listObj.Any();
        }
    }
}
