export interface DataReport{
    apiId : string,
    count : number
}


export interface DataSnap {
    id : string,
    requestTime : string,
    request : string,
    responseTime : string,
    response: string,
    duration : string
}
