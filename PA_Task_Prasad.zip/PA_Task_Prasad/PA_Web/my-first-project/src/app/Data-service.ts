import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
    
import {  Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { DataSnap,DataReport } from './DataSummary'; 
   
    
@Injectable({
  providedIn: 'root'
})
export class DataService {
    
  private apiURL = "https://localhost:7109/api/";
    
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
   
  constructor(private httpClient: HttpClient) { }
    
  getDataReport(): Observable<DataReport[]> {
    return this.httpClient.get<DataReport[]>(this.apiURL + 'Extract/')
    .pipe(
      catchError(this.errorHandler)
    )
  }
    
    
  getDataSnap(id: string): Observable<DataSnap> {
    return this.httpClient.get<DataSnap>(this.apiURL + 'Extract/Snap/' + id)
    .pipe(
      catchError(this.errorHandler)
    )
  }
    
  errorHandler(error: { error: { message: string; }; status: any; message: any; }) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
 }
}