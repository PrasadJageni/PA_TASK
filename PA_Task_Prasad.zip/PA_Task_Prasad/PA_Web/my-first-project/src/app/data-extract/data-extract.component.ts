import { Component, OnInit } from '@angular/core';
import { DataService } from '../Data-service';
import { DataReport } from '../DataSummary';

@Component({
  selector: 'app-data-extract',
  templateUrl: './data-extract.component.html',
  styleUrls: ['./data-extract.component.css']
})
export class DataExtractComponent implements OnInit {
  dataReport: DataReport[] = [];
  constructor(public dataService : DataService) { }

  ngOnInit(): void {
    this.dataService.getDataReport().subscribe((data: DataReport[])=>{
      this.dataReport = data;
      console.log(this.dataReport);
    })  
  }
}
