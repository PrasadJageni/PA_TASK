import { Component, Input, OnInit } from '@angular/core';
import { DataService } from '../Data-service';
import { DataSnap,DataReport } from '../DataSummary';

@Component({
  selector: 'app-data-snap',
  templateUrl: './data-snap.component.html',
  styleUrls: ['./data-snap.component.css']
})
export class DataSnapComponent implements OnInit {
  dataSnap : DataSnap = {
    id: '',
    requestTime: '',
    request: '',
    responseTime: '',
    response: '',
    duration: ''
  };
  constructor(public dataService : DataService ) { }

  ngOnInit(): void {

  }

  searchClick(id: any)
  {
    if(id.value == '')
    {
      this.dataSnap = this.dataSnap;
      return;
    }
    this.dataService.getDataSnap(id.value).subscribe((data: DataSnap)=>{
      this.dataSnap = data;
      console.log(this.dataSnap);
    })  
  }
}
